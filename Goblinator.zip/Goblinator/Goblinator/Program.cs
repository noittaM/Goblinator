﻿using System;

namespace Goblinator
{
    internal class Program
    {
        public static string Goblinator()
        {
            string Globin = "";
            bool extra = false, extraL = false, extraV = false;
            Random rnd = new Random();
            int temp, numofc, numofv = 1;



            temp = rnd.Next(0, 10);
            if (temp == 0) extra = true; //checking if the word is going to have letters that aren't {g, o, l, b, i, n}

            if (extra)
            {
                temp = rnd.Next(0, 4);//checking if the letter is going to be added to word or replace an already existing letter
                if (temp == 0)
                {
                    extraL = true;
                    extraV = true;
                    numofv = 2;
                }//if there is an extra letter it has to be a vowel because read notepad.
            }
            numofc = rnd.Next(1, 5);


            if (numofc == numofv)
            {
                if (!extra)
                {
                    while (numofv > 0)
                    {
                        Globin += CharGen(0);
                        Globin += CharGen(1);
                        numofv--;
                    }
                }
                else
                {
                    Globin += CharGen(0);
                    Globin += CharGen(3);
                    numofv--;
                    while (numofv > 0)
                    {
                        Globin += CharGen(0);
                        Globin += CharGen(1);
                        numofv--;
                    }//the CharGen(3) vowel would always be the second letter but I can't be bothered rn.
                }
                return Globin;
            }//when it's (1 C and 1 V) or (2 C and 2 V), checked for extra.

            if (numofc == 1 && numofv == 2)
            {
                if (extra)
                {
                    Globin += CharGen(1) + CharGen(0) + CharGen(3);
                }//again the extra is always going to be the last letter because I can't be bothered.
                else
                {
                    Globin += CharGen(1) + CharGen(0) + CharGen(1);
                }
                return Globin;
            }//when it's 1 C and 2 V, checked for extra.

            if (numofv + 1 == numofc)
            {
                Globin += CharGen(0);

                if (!extra)
                {
                    while (numofv != 0)
                    {
                        Globin += CharGen(1);
                        Globin += CharGen(0);
                        numofv--;
                    }

                }
                else
                {
                    if (numofv == 2)
                    {
                        Globin += CharGen(1);
                        Globin += CharGen(0);
                    }
                    Globin += CharGen(3);
                    Globin += CharGen(0);
                }
                return Globin;
            }//when it's (2 C and 1 V) or (3 C and 2 V), checked for extra.

            if (((numofc == 4) || (numofc == 3)) && numofv == 1)//can be simplified
            {
                Globin += CharGen(0) + CharGen(0);
                numofc = numofc - 2;
                if (extra)
                {
                    Globin += CharGen(3);
                    while (numofc > 0)
                    {
                        Globin += CharGen(0);
                        numofc--;
                    }
                }
                else
                {
                    Globin += CharGen(1);
                    while (numofc > 0)
                    {
                        Globin += CharGen(0);
                        numofc--;
                    }
                }
                return Globin;
            }//when it's (3 C and 1 V) or (4 C and 1 V), checked for extra.

            if (numofc == 4 && numofv == 2)
            {
                if (extra)
                {
                    Globin += CharGen(0) + CharGen(1) + CharGen(0) + CharGen(0) + CharGen(3) + CharGen(0);
                }
                else
                {
                    Globin += CharGen(0) + CharGen(1) + CharGen(0) + CharGen(0) + CharGen(1) + CharGen(0);
                }
                return Globin;
            }//when it's 3C and 2V.





            return "placeholder";

        }//issues:
         //the vowel being an extra letter, does not affect anything.
         //the syllables combination things are ass and can be improved.
         //the code in general sucks and is borderline ununderstandable.



        public static char CharGen(int a)
        {
            char[] goblinC = { 'g', 'b', 'l', 'n' };  //a=0
            char[] goblinV = { 'i', 'o' };       //a=1
            char[] notgoblinC = { 'a', 'c', 'd', 'f', 'h', 'j', 'k', 'm', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'z' };//a=2
            char[] notgoblinV = { 'e', 'u', 'y' };//a=3
            //ok there is 100% an easier way to do this wtf
            Random rnd = new Random();

            if (a == 0)
            {
                return goblinC[rnd.Next(0, goblinC.Length)];

            }
            else if (a == 1)
            {
                return goblinV[rnd.Next(0, goblinV.Length)];
            }
            else if (a == 2)
            {
                return notgoblinC[rnd.Next(0, notgoblinC.Length)];
            }
            else if (a == 3)
            {
                return notgoblinV[rnd.Next(0, notgoblinV.Length)];
            }
            else return '*';//you fucking idiot




        }//can return duplicates.
         //can't think of a better way, going to have to take a number 0-3 based on which
         //based on the value of a you choose what the character will be (goblinV, goblinC, not goblinV, not goblinC).
         //reason to not use unicode is because you shouldn't run a random on all characters.

        static void Main(string[] args)
        {
            string a;

            for (int i = 0; i < 4; i++)
            {
                a = Goblinator() + ",";
                Console.WriteLine(a);
            }
            Console.ReadKey();

        }
    }
}

